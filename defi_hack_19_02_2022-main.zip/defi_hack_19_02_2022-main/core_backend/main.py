from transport.server.server import server

if __name__ == '__main__':
    server.contact = "kda"
