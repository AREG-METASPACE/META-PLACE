data_skin = {
        'id': 'lol',
        'name': 'str',
        'image_link': 'str',
        'video_games': [{
            'id': 'str',
            'name': 'str',
            'link_to_game': 'str'
        }],
        'story': [{'from_id':'str',
                   'to_id':'str'}]


    }

user = {
    'id':'2345678',
    'user_name':'dfghjkl',
    'verificate': 'True',
    'nft_list': [
        {
            'id': '12312',
            'link_to_nft':'tytyt'
        }
    ]
}
